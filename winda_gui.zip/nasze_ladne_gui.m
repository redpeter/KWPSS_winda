function varargout = nasze_ladne_gui(varargin)
% NASZE_LADNE_GUI MATLAB code for nasze_ladne_gui.fig
%      NASZE_LADNE_GUI, by itself, creates a new NASZE_LADNE_GUI or raises the existing
%      singleton*.
%
%      H = NASZE_LADNE_GUI returns the handle to a new NASZE_LADNE_GUI or the handle to
%      the existing singleton*.
%
%      NASZE_LADNE_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NASZE_LADNE_GUI.M with the given input arguments.
%
%      NASZE_LADNE_GUI('Property','Value',...) creates a new NASZE_LADNE_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before nasze_ladne_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to nasze_ladne_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help nasze_ladne_gui

% Last Modified by GUIDE v2.5 24-Mar-2015 09:47:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @nasze_ladne_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @nasze_ladne_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before nasze_ladne_gui is made visible.
function nasze_ladne_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to nasze_ladne_gui (see VARARGIN)

% Choose default command line output for nasze_ladne_gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes nasze_ladne_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = nasze_ladne_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pietro1.
function pietro1_Callback(hObject, eventdata, handles)
set_param('Winda4_2012b/p1','Value','1');
set_param('Winda4_2012b/p2','Value','0');
set_param('Winda4_2012b/p3','Value','0');
% hObject    handle to pietro1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pietro2.
function pietro2_Callback(hObject, eventdata, handles)
set_param('Winda4_2012b/p1','Value','0');
set_param('Winda4_2012b/p2','Value','1');
set_param('Winda4_2012b/p3','Value','0');
% hObject    handle to pietro2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pietro3.
function pietro3_Callback(hObject, eventdata, handles)
set_param('Winda4_2012b/p1','Value','0');
set_param('Winda4_2012b/p2','Value','0');
set_param('Winda4_2012b/p3','Value','1');
% hObject    handle to pietro3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in start.
function start_Callback(hObject, eventdata, handles)
sim('Winda4_2012b',inf);
set_param('Winda4_2012b/p1','Value','0');
set_param('Winda4_2012b/p2','Value','0');
set_param('Winda4_2012b/p3','Value','0');
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in stop.
function stop_Callback(hObject, eventdata, handles)
set_param('Winda4_2012b/p1','Value','0');
set_param('Winda4_2012b/p2','Value','0');
set_param('Winda4_2012b/p3','Value','0');
set_param('Winda4_2012b','SimulationCommand','stop');
close;
% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
